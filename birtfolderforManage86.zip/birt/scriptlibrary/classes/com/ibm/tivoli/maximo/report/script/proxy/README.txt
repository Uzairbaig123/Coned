http://help.eclipse.org/indigo/index.jsp?topic=/org.eclipse.birt.doc/model/api/index.html
